// Maimoona Aziz
// 67070503473

#include <stdio.h>

int main(void){
    
}